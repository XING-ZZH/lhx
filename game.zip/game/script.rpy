# ============================================================
# 游戏脚本 
# ============================================================

init python:
    def play_movie(filename):
        renpy.block_rollback()
        renpy.pause(0.1, hard=True)
        renpy.movie_cutscene(filename)
        renpy.pause(0.1, hard=True)

# --- 图片与视频定义 ---
init python:
    for prefix, max_n in [("z", 8), ("j", 8), ("r", 7)]:
        for n in range(1, max_n + 1):
            renpy.image(f"{prefix}{n}", Movie(play=f"images/{prefix}{n}.mp4", channel="movie", loop=False))
            renpy.image(f"{prefix}c{n}A", Movie(play=f"images/{prefix}c{n}A.mp4", channel="movie", loop=False))
            renpy.image(f"{prefix}c{n}B", Movie(play=f"images/{prefix}c{n}B.mp4", channel="movie", loop=False))

init:
    image rc2C = Movie(play="images/rc2C.mp4", channel="movie", loop=False)
    image rc3C = Movie(play="images/rc3C.mp4", channel="movie", loop=False)
    image rc5C = Movie(play="images/rc5C.mp4", channel="movie", loop=False)
    
    image j1end = Movie(play="images/j1end.mp4", channel="movie", loop=False)
    image j4end = Movie(play="images/j4end.mp4", channel="movie", loop=False)
    image z1end = Movie(play="images/z1end.mp4", channel="movie", loop=False)
    image z3end = Movie(play="images/z3end.mp4", channel="movie", loop=False)
    image z5end = Movie(play="images/z5end.mp4", channel="movie", loop=False)
    image r1end = Movie(play="images/r1end.mp4", channel="movie", loop=False)
    image r4end = Movie(play="images/r4end.mp4", channel="movie", loop=False)
    image choose = "images/ooo.webp"
    image splash = "images/splashscreen.png"
    image S = Movie(play="images/片头a.mp4", channel="movie", loop=False)
    image bg = Movie(play="images/bg.mp4", channel="movie", loop=True)
    image intro = Movie(play="images/6人物简介新2.mp4", channel="movie", loop=False)
    image jo = Movie(play="images/jo.mp4", channel="movie", loop=False)
    image ro = Movie(play="images/ro.mp4", channel="movie", loop=False)
    image zo = Movie(play="images/zo.mp4", channel="movie", loop=False)
    image e = Movie(play="images/e.mp4", channel="movie", loop=False)

transform cover:
    xalign 0.5 yalign 0.5
    xysize (1920, 1080)
    fit "cover"

# 【新增】定义一个淡入动画，放在 screen 外面（init 阶段）

# 【修正】简化动画：只负责“平滑淡入”，不再负责“等待”
transform simple_fade_in:
    alpha 0.0               
    linear 1.2 alpha 1.0    # 用 0.8 秒的时间从透明变为不透明

screen unskippable_movie(movie_img, duration, skip_delay=7.0):
    default show_skip = False 

    modal True
    tag movie_layer
    
    # 屏蔽常规操作
    key "game_menu" action NullAction()
    key "mouseup_3" action NullAction()
    key "mouseup_1" action NullAction()
    key "K_SPACE" action NullAction()
    key "K_RETURN" action NullAction()
    key "K_KP_ENTER" action NullAction()



    # 播放视频

    add movie_img fit "cover" xysize (config.screen_width, config.screen_height)
    
    # 视频总时长倒计时
    timer (duration + 0.5 + 0.005*duration) action Return()

    # 延迟计时器：到达指定时间后，把变量改为 True
    timer skip_delay action SetScreenVariable("show_skip", True)

    # 只有当变量为 True 时，才渲染跳过按钮
    if show_skip:
        frame:
            xalign 0.98 yalign 0.02       
            background "#00000099"        
            padding (25, 12, 25, 12)      
            
            # 【修正】应用简化后的淡入动画（不再二次等待）
            at simple_fade_in
            
            textbutton "跳过 >>":
                text_color "#000000" 
                text_hover_color "#FFFFFF"
                text_size 32
                action Return() 
                if is_web_env:
                    action [Function(renpy.invoke_js, "window.RenpyVideoBridge.stop()"), Return()]
                else:
                    action Return()
# ============================================================
# 游戏正式开始
# ============================================================

label splashscreen:
    scene black
    $ renpy.pause(1.0)
    show splash with dissolve
    $ renpy.pause(2.0)
    scene black with dissolve
    $ renpy.pause(1.0)
    return

label start:
    $ quick_menu = False
    $ _preferences.fullscreen = True

    
    show screen watermark
    jump c0

# =========================
# 开场：用于选择故事线
# =========================
label c0:
    scene black
    call screen unskippable_movie("S", 155)

    menu:
        "请选择你的身份"
        "A 中国飞行员：封光临":
            jump zo
        "B 日籍飞行员：田中翔太":
            jump ro
        "C 机械师：李明宇":
            jump jo

############################################################
# ↓ 封光临线 (Z线)
############################################################
label zo:
    scene black
    call screen unskippable_movie("zo", 4)
    jump z1

label z1:
    
    show screen watermark
    call screen unskippable_movie("z1", 115)
    jump zc1

label zc1:
    scene zc1 at cover
    menu:
        "面对团长的怒斥，你选择"
        "去学飞":
            jump zc1A
        "认真拒绝":
            jump zc1B

label zc1A:
    scene black
    show screen watermark
    call screen unskippable_movie("zc1A", 16)
    jump z2

label zc1B:
    scene black
    
    show screen watermark
    call screen unskippable_movie("zc1B", 19)
    jump z1end

label z2:
    show screen watermark
    call screen unskippable_movie("z2", 41)
    jump zc2

label zc2:
    scene zc2 at cover
    menu:
        "面对难懂的知识与问题，你选择"
        "独自钻研":
            jump zc2A
        "与战友交流合作":
            jump zc2B

label zc2A:
    scene black
    show screen watermark
    call screen unskippable_movie("zc2A", 12)
    jump z3

label zc2B:
    scene black
    show screen watermark
    call screen unskippable_movie("zc2B", 16)
    jump z3

label z3:
    
    show screen watermark
    call screen unskippable_movie("z3", 57)
    jump zc3

label zc3:
    scene zc3 at cover
    menu:
        "面对毫无止境的监禁，你选择"
        "伺机逃跑":
            jump zc3B
        "等待救援":
            jump zc3A

label zc3A:
    scene black
    show screen watermark
    call screen unskippable_movie("zc3A", 49)
    jump z4

label zc3B:
    scene black
    show screen watermark
    call screen unskippable_movie("zc3B", 41)
    jump z3end

label z4:
    
    call screen unskippable_movie("z4", 39)
    jump zc4

label zc4:
    scene zc4 at cover
    menu:
        "面对学员对学习航理时的厌烦，你选择"
        "要求学员背熟航理":
            jump zc4A
        "商讨新的教学方法":
            jump zc4B

label zc4A:
    scene black
    show screen watermark
    call screen unskippable_movie("zc4A", 59)
    jump z5

label zc4B:
    scene black
    show screen watermark
    call screen unskippable_movie("zc4B", 41)
    jump z5

label z5:
    scene black
    show screen watermark
    call screen unskippable_movie("z5", 5)
    scene zc5 at cover
    jump zc5

label zc5:
    scene zc5 at cover
    menu:
        "面对已经压近的敌机，你选择"
        "立即登机,起飞迎敌":
            jump zc5B
        "立即隐蔽":
            jump zc5A

label zc5A:
    scene black
    show screen watermark
    call screen unskippable_movie("zc5A", 33)
    jump z6

label zc5B:
    scene black
    show screen watermark
    call screen unskippable_movie("zc5B", 20)
    jump z5end

label z6:
    show screen watermark
    call screen unskippable_movie("z6", 40)
    jump zc6

label zc6:
    scene zc6 at cover
    menu:
        "面对学员肆意尝试新动作，你选择"
        "不以为然":
            jump zc6B
        "严肃批评":
            jump zc6A

label zc6A:
    scene black
    show screen watermark
    call screen unskippable_movie("zc6A", 34)
    jump z7

label zc6B:
    scene black
    show screen watermark
    call screen unskippable_movie("zc6B", 29)
    jump z7

label z7:
    show screen watermark
    call screen unskippable_movie("z7", 99)
    jump zc7

label zc7:
    scene zc7 at cover
    menu:
        "面对学员直上九九高教的提议 你选择"
        "大力支持":
            jump zc7A
        "应该等待支援":
            jump zc7B 

label zc7A:
    scene black
    show screen watermark
    call screen unskippable_movie("zc7A", 24)
    jump z8

label zc7B:
    scene black
    show screen watermark
    call screen unskippable_movie("zc7B", 15)
    jump z8

label z8:
    show screen watermark
    call screen unskippable_movie("z8", 101)
    jump end 

############################################################
# ↓ 李明宇线 (J线)
############################################################
label jo:
    call screen unskippable_movie("jo", 4)
    jump j1

label j1:
    show screen watermark
    call screen unskippable_movie("j1", 33)
    scene jc1 at cover
    menu:
        "选择"
        "支援前线":
            jump jc1B
        "前往苏联":
            jump jc1A

label jc1A:
    scene black
    show screen watermark
    call screen unskippable_movie("jc1A", 112)
    jump jc2

label jc1B:
    scene black
    show screen watermark
    call screen unskippable_movie("jc1B", 13.1)
    jump j1end

label jc2:
    scene jc2 at cover
    menu:
        "选择"
        "去林子":
            jump jc2A
        "去村庄":
            jump jc2B

label jc2A:
    scene black
    show screen watermark
    call screen unskippable_movie("jc2A", 68)
    jump jc3

label jc2B:
    scene black
    show screen watermark
    call screen unskippable_movie("jc2B", 53)
    jump jc3

label jc3:
    scene jc3 at cover
    menu:
        "选择"
        "看机库":
            jump jc3A
        "看林子":
            jump jc3B

label jc3A:
    scene black
    show screen watermark
    call screen unskippable_movie("jc3A", 35)
    jump jc4

label jc3B:
    scene black
    show screen watermark
    call screen unskippable_movie("jc3B", 38)
    jump jc4

label jc4:
    scene jc4 at cover
    menu:
        "选择"
        "自己拆":
            jump jc4A
        "等支援":
            jump jc4B

label jc4A:
    scene black
    show screen watermark
    call screen unskippable_movie("jc4A", 8)
    jump j5

label jc4B:
    scene black
    show screen watermark
    call screen unskippable_movie("jc4B", 22)
    jump j4end 

label j5:
    show screen watermark
    call screen unskippable_movie("j5", 28)
    jump jc5

label jc5:
    scene jc5 at cover
    menu:
        "选择"
        "主动请缨负责最艰难的火车押运任务":
            jump jc5A
        "申请承担风险更高的断后掩护任务":
            jump jc5B

label jc5A:
    scene black
    show screen watermark
    call screen unskippable_movie("jc5A", 54)
    jump jc6

label jc5B:
    scene black
    show screen watermark
    call screen unskippable_movie("jc5B", 53)
    jump jc6

label jc6:
    scene jc6 at cover
    menu:
        "选择"
        "主动召开党组织会议":
            jump jc6A
        "先找思想最动摇的战士个别谈话":
            jump jc6B

label jc6A:
    scene black
    show screen watermark
    call screen unskippable_movie("jc6A", 80)
    jump jc7

label jc6B:
    scene black
    show screen watermark
    call screen unskippable_movie("jc6B", 108)
    jump jc7

label jc7:
    scene jc7 at cover
    menu:
        "选择"
        "回撤":
            jump jc7A
        "继续":
            jump jc7B

label jc7A:
    scene black
    show screen watermark
    call screen unskippable_movie("jc7A", 36)
    jump jc8

label jc7B:
    scene black
    show screen watermark
    call screen unskippable_movie("jc7B", 37)
    jump jc8

label jc8:
    scene jc8 at cover
    menu:
        "最终抉择" 
        "仍然坚守一线，继续做机械师":
            jump jc8A
        "接受组织安排，去机关":
            jump jc8B 

label jc8A:
    scene black
    show screen watermark
    call screen unskippable_movie("jc8A", 71)
    jump end

label jc8B:
    scene black
    show screen watermark
    call screen unskippable_movie("jc8B", 31)
    jump end

############################################################
# ↓ 田中翔太线 (R线)
############################################################
label ro:
    scene black
    call screen unskippable_movie("ro", 3)
    jump r1
    $ renpy.fetch("images/rc1.png")

label r1:
    show screen watermark
    call screen unskippable_movie("r1", 37)
    jump rc1

label rc1:
    menu:
        "真的要投弹吗？"
        "投弹":
            jump rc1A
        "不投":
            jump rc1B

label rc1A:
    scene black
    show screen watermark
    call screen unskippable_movie("rc1A", 26)
    jump rc2

label rc1B:
    scene black
    show screen watermark
    call screen unskippable_movie("rc1B", 116)
    jump r1end

label rc2:
    scene rc3 at cover
    menu:
        "面对询问，你说："
        "万死不辞":
            jump rc2A
        "地上的孩子...":
            jump rc2B
        "发晕":
            jump rc2C

label rc2A:
    scene black
    show screen watermark
    call screen unskippable_movie("rc2A", 7)
    jump r2

label rc2B:
    scene black
    show screen watermark
    call screen unskippable_movie("rc2B", 6)
    jump r2

label rc2C:
    scene black
    show screen watermark
    call screen unskippable_movie("rc2C", 11)
    jump r2

label r2:
    show screen watermark
    call screen unskippable_movie("r2", 7)
    jump rc3
label rc3:
    scene rc2 at cover
    menu:
        "面对眼前奇怪的劳工，你准备："
        "直接上前":
            jump rc3A
        "沉默犹豫":
            jump rc3B

label rc3A:
    scene black
    show screen watermark
    call screen unskippable_movie("rc3A", 6)
    jump r4

label rc3B:
    scene black
    show screen watermark
    call screen unskippable_movie("rc3B", 9)
    jump r4

label r4:
    show screen watermark
    call screen unskippable_movie("r4", 129)
    jump rc4

label rc4:
    scene rc4 at cover
    menu:
        "面对邀请，你的想法是："
        "逃回日本":
            jump rc4A
        "坚守在这":
            jump rc4B

label rc4A:
    scene black
    show screen watermark
    call screen unskippable_movie("rc4A", 83)
    jump r4end

label rc4B:
    scene black
    show screen watermark
    call screen unskippable_movie("rc4B", 60)
    jump rc5

label rc5:
    scene rc5 at cover
    menu:
        "你被学员指责，你选择："
        "独自坐于雪地":
            jump rc5A
        "去找林弥一郎":
            jump rc5B
        "回教室继续上课":
            jump rc5C

label rc5A:
    scene black
    show screen watermark
    call screen unskippable_movie("rc5A", 29)
    jump r6

label rc5B:
    scene black
    show screen watermark
    call screen unskippable_movie("rc5B",26)
    jump r6

label rc5C:
    scene black
    show screen watermark
    call screen unskippable_movie("rc5C", 16)
    jump r6

label r6:
    scene black
    show screen watermark
    call screen unskippable_movie("r6", 43)
    jump rc6

label rc6:
    scene rc6 at cover
    menu:
        "选择"
        "坚守传统教学法":
            jump rc6A
        "试试教学法改革":
            jump rc6B

label rc6A:
    show screen watermark
    call screen unskippable_movie("rc6A", 76)
    jump r7

label rc6B:
    show screen watermark
    call screen unskippable_movie("rc6B", 30)
    jump r7

label r7:
    show screen watermark
    call screen unskippable_movie("r7", 17)
    jump end 

############################################################
# ↓ BE (Bad End) 回溯节点
############################################################
label z1end:
    scene black with fade
    menu:
        "BE"
        "回溯":
            jump z1
        "标题画面":
            return

label z3end:
    scene black with fade
    menu:
        "BE"
        "回溯":
            jump z3
        "标题画面":
            return

label z5end:
    scene black with fade
    menu:
        "BE"
        "回溯":
            jump z5
        "标题画面":
            return

label r1end:
    scene black with fade
    menu:
        "BE"
        "回溯":
            jump r1
        "标题画面":
            return

label j1end:
    scene black with fade
    menu:
        "BE"
        "回溯":
            jump j1
        "标题画面":
            return

label j4end:
    scene black with fade
    menu:
        "BE"
        "回溯":
            jump jc4
        "标题画面":
            return

label r4end:
    scene black with fade
    menu:
        "BE"
        "回溯":
            jump r4
        "标题画面":
            return

############################################################
# ↓ 通用通关结局
############################################################
label end:
    scene black with fade
    stop music
    
    call screen unskippable_movie("e", 3) 
    
    menu:
        "本线完毕"
        "再玩一次":
            jump start
        "标题菜单":
            return