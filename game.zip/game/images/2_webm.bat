@echo off
set "CRF=30"
set "ABIT=128k"
set "SCALE=scale=1280:720"

for %%f in (*.mp4) do (
  echo Converting %%f ...
  ffmpeg -i "%%f" -vf %SCALE% -c:v libvpx-vp9 -crf %CRF% -b:v 0 -c:a libopus -b:a %ABIT% "%%~nf.webm"
)
pause