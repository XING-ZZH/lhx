# ============================================================
# 视频预加载系统 (终极适配版)
# ============================================================

init python:
    # 1. 汇总所有你在 script.rpy 中定义过的“图像名称”（注意：不是文件路径！）
    PRELOAD_IMAGE_NAMES = [
        "S", "bg", "intro", "zo", "jo", "ro", "e"
    ]
    
    for prefix in ["z", "j", "r"]:
        for i in range(1, 9):
            PRELOAD_IMAGE_NAMES.extend([
                f"{prefix}{i}", 
                f"{prefix}c{i}A", 
                f"{prefix}c{i}B"
            ])
            
    PRELOAD_IMAGE_NAMES.extend([
        "rc2C", "rc3C", "rc5C",
        "z1end", "z3end", "z5end",
        "j1end", "j4end", "r1end", "r4end"
    ])

    def preload_videos():
        """
        强制 Ren'Py 提前渲染所有视频的第一帧，彻底消除播放时的卡顿。
        """
        
        
        for idx, img_name in enumerate(PRELOAD_IMAGE_NAMES):
            # 从 Ren'Py 内部获取你定义的 Movie 对象
            movie_obj = renpy.display.image.images.get((img_name,))
            
            if movie_obj is None:
                
                continue
                
            try:
                # 【核心魔法】强制渲染第一帧！
                # 这会触发解码器初始化并将第一帧上传到 GPU
                movie_obj.render(config.screen_width, config.screen_height, 0, 0)
                
            except Exception as e:
                continue
                
        

# 每次进入主菜单时自动触发
label before_main_menu:
    $ preload_videos()
    return